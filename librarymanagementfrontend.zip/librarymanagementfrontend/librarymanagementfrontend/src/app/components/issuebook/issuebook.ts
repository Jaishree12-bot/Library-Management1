import { Component, OnInit } from '@angular/core';
import { Services } from '../../service/services';

@Component({
  selector: 'app-issuebook',
  standalone: false,
  templateUrl: './issuebook.html',
  styleUrls: ['./issuebook.css']
})
export class Issuebook implements OnInit {

  readers: any[] = [];
  suggestions: any[] = [];
  bookQuery = '';

  popupMessage: string = '';

  issue = {
    readerId: '',
    bookId: '',
    issueDate: '',
    returnDate: ''
  };

  constructor(private service: Services) {}

  ngOnInit() {
    this.loadReaders();
  }

  loadReaders() {
    this.service.getAllReaders().subscribe({
      next: (res) => this.readers = res,
      error: () => console.error("Failed to load readers")
    });
  }

  // ---------------- BOOK AUTOCOMPLETE ----------------
  onBookQueryChange(query: string) {
    if (!query || query.trim().length < 1) {
      this.suggestions = [];
      return;
    }

    this.service.findByBookName(query).subscribe({
      next: (res) => this.suggestions = res,
      error: () => this.suggestions = []
    });
  }

  selectSuggestion(book: any) {
    this.bookQuery = book.bookName;
    this.issue.bookId = book.bookId;
    this.suggestions = [];
  }

  // ---------------- DATE HANDLING ----------------
  calculateReturnDate() {
    if (!this.issue.issueDate) return;

    const date = new Date(this.issue.issueDate);
    date.setDate(date.getDate() + 7);

    this.issue.returnDate = date.toISOString().split('T')[0];
  }

  validateIssueDate() {
    const today = new Date().toISOString().split('T')[0];

    if (this.issue.issueDate < today) {
      this.popupMessage = "Issue date cannot be earlier than today.";
      this.issue.issueDate = "";
      this.issue.returnDate = "";
    }
  }

  // ---------------- SUBMIT ISSUE ----------------
  submitIssue() {

    if (!this.issue.readerId || !this.issue.bookId || !this.issue.issueDate) {
      this.popupMessage = "All fields are required!";
      return;
    }

    const payload = {
      readerId: Number(this.issue.readerId),
      bookId: Number(this.issue.bookId),
      issueDate: this.issue.issueDate,
      returnDate: this.issue.returnDate
    };

    console.log("Payload sending:", payload);

    this.service.issueBook(payload).subscribe({
      next: (res) => {
        console.log("Issue saved:", res);
        this.popupMessage = "Book issued successfully!";
      },
      error: (err) => {
        console.error("Backend error:", err);
        this.popupMessage = err.error || "Something went wrong!";
      }
    });
  }

  closePopup() {
    this.popupMessage = "";
  }
}
