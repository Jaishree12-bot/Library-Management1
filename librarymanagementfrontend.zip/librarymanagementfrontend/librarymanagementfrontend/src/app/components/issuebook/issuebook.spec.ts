import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Issuebook } from './issuebook';

describe('Issuebook', () => {
  let component: Issuebook;
  let fixture: ComponentFixture<Issuebook>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Issuebook]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Issuebook);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
