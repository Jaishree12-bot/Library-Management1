import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Managebook } from './managebook';

describe('Managebook', () => {
  let component: Managebook;
  let fixture: ComponentFixture<Managebook>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Managebook]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Managebook);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
