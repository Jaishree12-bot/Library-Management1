import { Component } from '@angular/core';
import { Services } from '../../service/services';

@Component({
  selector: 'app-addlibrarian',
  standalone: false,
  templateUrl: './addlibrarian.html',
  styleUrls: ['./addlibrarian.css']
})
export class Addlibrarian {

  today = new Date().toISOString().split("T")[0];
  popupMessage: string = "";

  librarian = {
    readerName: '',
    email: '',
    phoneNo: '',
    address: '',
    dateOfBirth: '',
    password: '',
    role: 'LIBRARIAN'   // ALWAYS librarian for this form
  };

  constructor(private service: Services) {}

  // Stop phone number at 10 digits
  stopAtTenDigits() {
    if (this.librarian.phoneNo.length > 10) {
      this.librarian.phoneNo = this.librarian.phoneNo.substring(0, 10);
    }
  }

  // Show popup message
  showPopup(msg: string) {
    this.popupMessage = msg;
  }

  // Close popup
  closePopup() {
    this.popupMessage = "";
  }

  // Add Librarian
  addLibrarian(form: any) {
    const phonePattern = /^[6-9][0-9]{9}$/;
    const passPattern =
      /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,20}$/;

    // -------------------------------
    // VALIDATION SECTION
    
    if (!this.librarian.readerName.trim())
      return this.showPopup("Librarian name is required");

    if (!this.librarian.email.trim())
      return this.showPopup("Email is required");

    if (!phonePattern.test(this.librarian.phoneNo))
      return this.showPopup("Phone must be 10 digits & start with 6–9");

    const dob = new Date(this.librarian.dateOfBirth);
    if (dob >= new Date())
      return this.showPopup("Date of Birth cannot be a future date");

    if (!this.librarian.address.trim())
      return this.showPopup("Address is required");

    if (!passPattern.test(this.librarian.password))
      return this.showPopup(
        "Password must have uppercase, number & special character (min 6 chars)"
      );

    // -------------------------------
    // API CALL — SUBMIT DATA
    // -------------------------------

    this.service.registerReader(this.librarian).subscribe({
      next: () => {
        this.showPopup("Librarian added successfully!");
        form.resetForm();
        this.librarian.role = "LIBRARIAN"; // Reset role after form clear
      },
      error: (err) => {
        if (err.status === 409) {
          this.showPopup(
            err.error?.message ||
            "User already exists OR invalid details!"
          );
        } else {
          this.showPopup("Server error, please try again!");
        }
      }
    });
  }
}
