import { Component } from '@angular/core';
import { Services } from '../../service/services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updatepassword',
  standalone: false,
  templateUrl: './updatepassword.html',
  styleUrl: './updatepassword.css',
})
export class Updatepassword {

  oldPassword = '';
  newPassword = '';
  message = '';
  passwordError = '';

  // 6–20 chars, uppercase, lowercase, number, special char
  passwordPattern =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,20}$/;

  constructor(private service: Services, private router: Router) {}

  validateNewPassword() {
    if (!this.passwordPattern.test(this.newPassword)) {
      this.passwordError =
        'Password must be 6–20 characters and include uppercase, lowercase, number & special character.';
    } else {
      this.passwordError = '';
    }
  }

  updatePassword() {

    if (this.passwordError) return;

    // ✅ GET ID SAFELY
    const readerId = localStorage.getItem('readerId');
    const librarianId = localStorage.getItem('librarianId');

    const id = readerId
      ? Number(readerId)
      : librarianId
      ? Number(librarianId)
      : 0;

    // ❌ No valid session
    if (!id || id === 0) {
      alert('Session expired. Please login again.');
      this.router.navigate(['/login']);
      return;
    }

    const body = {
      oldPassword: this.oldPassword,
      newPassword: this.newPassword
    };

    this.service.updatePassword(id, body).subscribe({
      next: () => {
        alert('Password Updated Successfully!');

        // redirect based on role
        if (readerId) {
          this.router.navigate(['/readerhomepage']);
        } else {
          this.router.navigate(['/librarianhomepage']);
        }
      },
      error: (err) => {
        this.message = err.error || 'Password update failed';
      }
    });
  }
}
