import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Services } from '../../service/services';

@Component({
  selector: 'app-login',
  standalone:false,
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class Login {

  loginData = {
    readerName: '',
    password: ''
  };

  constructor(
    private service: Services,
    private router: Router
  ) {}

  login() {

    // ✅ Frontend validation
    if (!this.loginData.readerName || !this.loginData.password) {
      alert('All fields are required');
      return;
    }

    this.service.loginReader(this.loginData).subscribe({

      next: (res: any) => {
        alert('Login Successful');

        if (res.role === 'LIBRARIAN') {
          localStorage.setItem('role', 'LIBRARIAN');
          localStorage.setItem('librarianId', res.readerId);
          localStorage.setItem('librarianName', res.readerName);
          this.router.navigate(['/librarianhomepage']);
        } else {
          localStorage.setItem('role', 'READER');
          localStorage.setItem('readerId', res.readerId);
          localStorage.setItem('readerName', res.readerName);
          this.router.navigate(['/readerhomepage']);
        }
      },

      error: (err) => {
        if (err.status === 401) {
          alert('Invalid username or password');
        } else {
          alert('Server error. Please try again later.');
        }
      }
    });
  }
}
