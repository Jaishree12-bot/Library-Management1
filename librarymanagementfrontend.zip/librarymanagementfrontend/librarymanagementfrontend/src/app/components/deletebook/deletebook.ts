import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Services } from '../../service/services';

@Component({
  selector: 'app-deletebook',
  standalone:false,
  templateUrl: './deletebook.html',
  styleUrls: ['./deletebook.css']
})
export class Deletebook implements OnInit {

  books: any[] = [];
  loading = true;
  successMessage = '';
  errorMessage = '';

  constructor(private service: Services,private cd:ChangeDetectorRef ) {}

  ngOnInit() {
    this.loadBooks();   // <-- LOAD EVERY TIME COMPONENT OPENS
  }

  loadBooks() {
    this.loading = true;
    this.service.getAllBooks().subscribe({
      next: (res) => {
        this.books = res;
        this.loading = false;
        this.cd.detectChanges();
      },
      error: () => {
        this.errorMessage = "Failed to load books.";
        this.loading = false;
      }
    });
  }

  deleteBook(id: number) {
  if (!confirm("Are you sure you want to delete this book?")) {
    return;
  }

  this.service.deleteBook(id).subscribe({
    next: () => {
      alert("Book deleted successfully!");
      this.loadBooks(); // Refresh table after delete
    },
    error: () => {
      alert("Failed to delete book.");
    }
  });
}



}
