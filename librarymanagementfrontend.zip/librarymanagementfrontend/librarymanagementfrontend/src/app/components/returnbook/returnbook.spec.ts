import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Returnbook } from './returnbook';

describe('Returnbook', () => {
  let component: Returnbook;
  let fixture: ComponentFixture<Returnbook>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Returnbook]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Returnbook);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
