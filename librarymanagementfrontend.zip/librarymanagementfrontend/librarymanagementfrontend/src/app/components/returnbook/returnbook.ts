import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Services } from '../../service/services';

@Component({
  selector: 'app-returnbook',
  standalone: false,
  templateUrl: './returnbook.html',
  styleUrls: ['./returnbook.css'],
})
export class Returnbook implements OnInit {

  readerId: any = "";
  readers: any[] = [];
  issuedBooks: any[] = [];

  constructor(private service: Services,private cd:ChangeDetectorRef) {}

  ngOnInit() {
    this.loadReaders();
  }

  loadReaders() {
    this.service.getAllReaders().subscribe(data => {
      this.readers = data;
      this.cd.detectChanges();
    });
  }

  loadIssuedBooks() {
    if (!this.readerId) return;

    this.service.getIssuedBooks(this.readerId).subscribe(data => {
      this.issuedBooks = data.filter(book => book.status === "ISSUED");
    });
  }

  
 returnBook(issueId: number) {

  if (!confirm("Are you sure?")) return;

  this.service.returnBook(issueId).subscribe({
    next: () => {
      alert("Book returned successfully!");

      // ⭐ Remove row immediately
      this.issuedBooks = this.issuedBooks.filter(b => b.issueId !== issueId);
    },
    error: (err) => {
      console.error("Error while returning:", err);
      alert("Something went wrong while returning!");
    }
  });
}


}
