import { Component } from '@angular/core';
import { Services } from '../../service/services';

@Component({
  selector: 'app-searchbook',
  standalone:false,
  templateUrl: './searchbook.html',
  styleUrls: ['./searchbook.css']
})
export class Searchbook {
  name: string = "";
  books: any[] = [];
  error = '';

  constructor(private service: Services) {}

  search() {
    this.error = '';
    if (this.name.trim() === "") {
      this.error = "Please enter a book name.";
      this.books = [];
      return;
    }
    this.service.findByBookName(this.name.trim()).subscribe({
      next: (res: any[]) => {
        this.books = res || [];
      },
      error: (err) => {
        console.error(err);
        this.error = "Search failed.";
      }
    });
  }
}
