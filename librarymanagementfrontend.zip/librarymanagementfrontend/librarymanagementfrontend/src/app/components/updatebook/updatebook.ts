import { Component, OnInit } from '@angular/core';
import { Services } from '../../service/services';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-updatebook',
  standalone:false,
  templateUrl: './updatebook.html',
  styleUrls: ['./updatebook.css']
})
export class Updatebook implements OnInit {
  bookId: number | null = null;
  book: any = {};
  bookFound = false;
  errorMessage = '';
  successMessage = '';

  constructor(private service: Services, private route: ActivatedRoute) {}

  ngOnInit(): void {
    // if route provides id, auto search
    this.route.queryParams.subscribe(q => {
      if (q['id']) {
        this.bookId = +q['id'];
        this.searchBook();
      }
    });
  }

  searchBook() {
    this.errorMessage = '';
    this.successMessage = '';

    if (!this.bookId) {
      this.errorMessage = 'Please enter a valid Book ID.';
      return;
    }

    this.service.getBookById(this.bookId).subscribe({
      next: (data) => {
        this.book = data;
        this.bookFound = true;
        this.errorMessage = '';
      },
      error: (err) => {
        console.error(err);
        this.bookFound = false;
        this.book = {};
        this.errorMessage = 'Book not found!';
      }
    });
  }

  updateBook() {
    if (!this.bookFound || !this.bookId) {
      this.errorMessage = 'Search a book first!';
      return;
    }
    this.service.updateBook(this.bookId, this.book).subscribe({
      next: () => {
        this.successMessage = 'Book updated successfully!';
        this.errorMessage = '';
      },
      error: (err) => {
        console.error(err);
        this.errorMessage = 'Failed to update the book.';
      }
    });
  }
}
