import { Component, ViewEncapsulation } from '@angular/core';
import { Services } from '../../service/services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addbook',
  standalone:false,
  templateUrl: './addbook.html',
  styleUrls: ['./addbook.css'],
  encapsulation: ViewEncapsulation.None
})
export class Addbook {

  book = {
    bookName: '',
    author: '',
    category: '',
    imageUrl: '',
    publisherName: '',
    publishYear: ''
  };

  selectedFile: File | null = null;
  preview: string | ArrayBuffer | null = null;

  constructor(private service: Services, private router: Router) {}

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];

    if (!this.selectedFile) return;

    const reader = new FileReader();
    reader.onload = () => {
      this.preview = reader.result;
    };
    reader.readAsDataURL(this.selectedFile);
  }

  addBook() {
    if (!this.selectedFile) {
      alert("Please choose an image");
      return;
    }

    const formData = new FormData();
    formData.append("file", this.selectedFile);

    this.service.uploadImage(formData).subscribe({
      next: (res: any) => {
        this.book.imageUrl = res.imageUrl;

        this.service.addBook(this.book).subscribe({
          next: () => {
            alert("Book added successfully!");
            this.resetForm();
          },
          error: () => alert("Failed to save book")
        });
      },
      error: () => alert("Image upload failed")
    });
  }

  goBack() {
    this.router.navigate(['/librarianhomepage']);
  }

  resetForm() {
    this.book = { 
      bookName: '', 
      author: '', 
      category: '', 
      imageUrl: '',
      publisherName: '',
      publishYear: '' 
    };
    this.preview = null;
    this.selectedFile = null;
  }
}
