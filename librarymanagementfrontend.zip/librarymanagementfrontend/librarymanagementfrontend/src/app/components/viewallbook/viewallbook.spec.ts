import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Viewallbook } from './viewallbook';

describe('Viewallbook', () => {
  let component: Viewallbook;
  let fixture: ComponentFixture<Viewallbook>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Viewallbook]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Viewallbook);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
