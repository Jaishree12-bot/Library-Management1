import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Services } from '../../service/services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewallbook',
  standalone:false,
  templateUrl: './viewallbook.html',
  styleUrls: ['./viewallbook.css']
})
export class Viewallbook implements OnInit {
  books: any[] = [];
  filteredBooks: any[] = [];
  searchText: string = '';
loading:any;
error:any;
  constructor(private service: Services, private router: Router,private cd:ChangeDetectorRef) {}

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks() {
    this.service.getAllBooks().subscribe(data => {
      this.books = data;
      this.filteredBooks = data;
      this.cd.detectChanges();
    });
  }

  search() {
    const t = this.searchText.trim().toLowerCase();
    this.filteredBooks = this.books.filter(b =>
      b.bookName.toLowerCase().includes(t) ||
      b.author.toLowerCase().includes(t) ||
      b.category.toLowerCase().includes(t)
    );
  }

  goToUpdate(bookId: number) {
    this.router.navigate(['/updatebook'], { queryParams: { id: bookId } });
  }
  

}
