import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Services } from '../../service/services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-readerhomepage',
  standalone: false,
  templateUrl: './readerhomepage.html',
  styleUrls: ['./readerhomepage.css']
})
export class Readerhomepage implements OnInit {

  readerName = '';
  readerId!: number;

  menuOpen = false;
  view: 'recommended' | 'reserved' | 'issued' = 'recommended';

  allBooks: any[] = [];
  reservedBooks: any[] = [];
  issuedBooks: any[] = [];

  // 🔍 Search
  searchText = '';
  filteredSuggestions: any[] = [];
  showSuggestions = false;

  constructor(
    private service: Services,
    private router: Router,
    private cd: ChangeDetectorRef
  ) {}

  // ================= INIT =================
  ngOnInit(): void {
    this.readerId = Number(localStorage.getItem('readerId'));
    this.readerName = localStorage.getItem('readerName') || 'Reader';

    this.loadAllBooks();
    this.loadIssuedBooks();
  }

  // ================= MENU =================
  toggleMenu() {
    this.menuOpen = !this.menuOpen;
  }

  logout() {
    localStorage.removeItem('readerId');
    localStorage.removeItem('readerName');
    localStorage.removeItem('token');
    this.router.navigate(['/login'], { replaceUrl: true });
  }

  goToUpdatePassword() {
    this.router.navigate(['/update-password']);
  }

  // ================= DATA LOADERS =================
  loadAllBooks() {
    this.service.getAllBooks().subscribe({
      next: books => {
        this.allBooks = books;
        this.loadReservedBooks();   // after books load
        this.loadIssuedBooks();
        this.cd.detectChanges();
      },
      error: () => this.allBooks = []
    });
  }

  loadReservedBooks() {
    this.service.getReservationsByReader(this.readerId).subscribe({
      next: res => {
        this.reservedBooks = res.map(r => {
          const book = this.allBooks.find(b => b.bookId === r.bookId);
          return {
            ...r,
            bookName: book?.bookName,
            image_url: book?.imageUrl
          };
        });
        this.cd.detectChanges();
      }
    });
  }

  loadIssuedBooks() {
    this.service.getIssuedBooks(this.readerId).subscribe({
      next: issued => {
        console.log('ISSUED RAW:', issued);

        this.issuedBooks = issued.map(i => {
          const book = this.allBooks.find(b => b.bookId === i.bookId);
          return {
            ...i,
            bookName: book?.bookName,
            imageUrl: book?.imageUrl
          };
        });
        this.cd.detectChanges();
      },
      error: () => this.issuedBooks = []
    });
  }

  // ================= ACTIONS =================
  reserveBook(bookId: number) {
    this.router.navigate(['/reservebook'], {
      queryParams: { bookId }
    });
  }

  // ================= SEARCH (Google-style) =================
  onSearchChange() {
    if (!this.searchText.trim()) {
      this.filteredSuggestions = [];
      this.showSuggestions = false;
      return;
    }

    this.filteredSuggestions = this.allBooks.filter(book =>
      book.bookName.toLowerCase().includes(this.searchText.toLowerCase())
    );

    this.showSuggestions = this.filteredSuggestions.length > 0;
  }

  selectSuggestion(bookName: string) {
    this.searchText = bookName;
    this.showSuggestions = false;

    this.allBooks = this.allBooks.filter(
      b => b.bookName === bookName
    );
  }

  clearSearch() {
    this.searchText = '';
    this.showSuggestions = false;
    this.loadAllBooks();   
  }
}
