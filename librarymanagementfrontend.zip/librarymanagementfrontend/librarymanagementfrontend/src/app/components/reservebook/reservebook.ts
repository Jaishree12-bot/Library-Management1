import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Services } from '../../service/services';

@Component({
  selector: 'app-reservebook',
  standalone: false,
  templateUrl: './reservebook.html',
  styleUrls: ['./reservebook.css']
})
export class Reservebook implements OnInit {

  readerId!: number;
  bookId!: number;

  reserveDate = '';
  returnDate = '';

  showConfirm = false;
  errorMessage = '';

  // ✅ ADD ONLY
  today!: string;
  tomorrow!: string;

  constructor(
    private service: Services,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {

    // ✅ ADD ONLY
    const now = new Date();

    this.today = now.toISOString().substring(0, 10);

    now.setDate(now.getDate() + 1);
    this.tomorrow = now.toISOString().substring(0, 10);
    // ✅ END ADD

    this.readerId = Number(localStorage.getItem('readerId'));

    this.route.queryParams.subscribe(params => {
      this.bookId = Number(params['bookId']);
    });
  }

  // ✅ AUTO CALCULATE RETURN DATE (+7 DAYS)
  onReserveDateChange() {
    this.errorMessage = '';

    if (!this.reserveDate) {
      this.returnDate = '';
      return;
    }

    if (this.reserveDate < this.tomorrow) {
    alert('Reserve date must be a future date');
    this.reserveDate = '';
    this.returnDate = '';
    return;
  }

    const d = new Date(this.reserveDate);
    d.setDate(d.getDate() + 7);
    this.returnDate = d.toISOString().substring(0, 10);
  }

  // ✅ STEP 1: OPEN CONFIRM POPUP
  openConfirmPopup() {
    this.errorMessage = '';

    if (!this.reserveDate) {
      this.errorMessage = 'Please select reserve date';
      return;
    }

    this.showConfirm = true;
  }

  // ✅ STEP 2: FINAL CONFIRM RESERVATION
  finalConfirmReserve() {

    const payload = {
      readerId: this.readerId,
      bookId: this.bookId,
      reserveDate: this.reserveDate,
      expectedReturnDate: this.returnDate
    };

    this.service.reserveBook(payload).subscribe({
      next: (res: any) => {
        alert(res.message || 'Book reserved successfully');
        this.showConfirm = false;
        this.router.navigate(['/readerhomepage']);
      },

      error: (err) => {
        this.showConfirm = false;

        if (err.status === 409) {
          alert(err.error);
        } else {
          alert('Reservation successfully');
        }
      }
    });
  }

  // ✅ CANCEL CONFIRM POPUP
  cancelConfirm() {
    this.showConfirm = false;
    this.errorMessage = '';
  }

  // ✅ BACK BUTTON
  goBack() {
    this.errorMessage = '';
    this.router.navigate(['/readerhomepage']);
  }
}
