import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Reservebook } from './reservebook';

describe('Reservebook', () => {
  let component: Reservebook;
  let fixture: ComponentFixture<Reservebook>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Reservebook]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Reservebook);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
