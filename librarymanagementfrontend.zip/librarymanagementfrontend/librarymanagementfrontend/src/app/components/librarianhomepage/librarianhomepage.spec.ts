import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Librarianhomepage } from './librarianhomepage';

describe('Librarianhomepage', () => {
  let component: Librarianhomepage;
  let fixture: ComponentFixture<Librarianhomepage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Librarianhomepage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Librarianhomepage);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
