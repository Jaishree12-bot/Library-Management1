import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

/* COMPONENTS */
import { Welcome } from './components/welcome/welcome';
import { Login } from './components/login/login';
import { Readerregister } from './components/readerregister/readerregister';
import { Readerhomepage } from './components/readerhomepage/readerhomepage';
import { Librarianhomepage } from './components/librarianhomepage/librarianhomepage';
import { Issuebook } from './components/issuebook/issuebook';
import { Managebook } from './components/managebook/managebook';
import { Addbook } from './components/addbook/addbook';
import { Updatebook } from './components/updatebook/updatebook';
import { Deletebook } from './components/deletebook/deletebook';
import { Searchbook } from './components/searchbook/searchbook';
import { Viewallbook } from './components/viewallbook/viewallbook';
import { Reservebook } from './components/reservebook/reservebook';
import { Returnbook } from './components/returnbook/returnbook';
import { Addlibrarian } from './components/addlibrarian/addlibrarian';
import { RouterModule } from '@angular/router';
import { Reports } from './components/reports/reports';
import { Updatepassword } from './components/updatepassword/updatepassword';
import { About } from './components/about/about';


@NgModule({
  declarations: [
    App,
    Welcome,
    Login,
    Readerregister,
    Readerhomepage,
    Librarianhomepage,
    Issuebook,
    Managebook,
    Addbook,
    Updatebook,
    Deletebook,
    Searchbook,
    Viewallbook,
    Reservebook,
    Returnbook,
    Addlibrarian,
    Reports,
    Updatepassword,
    About,
   
  ],

  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    CommonModule,
    RouterModule
  ],

  providers: [
    provideBrowserGlobalErrorListeners()
  ],

  bootstrap: [App]
})
export class AppModule {}
