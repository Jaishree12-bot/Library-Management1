import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Login } from './components/login/login';
import { Welcome } from './components/welcome/welcome';
import { Readerregister } from './components/readerregister/readerregister';
import { Readerhomepage } from './components/readerhomepage/readerhomepage';
import { Librarianhomepage } from './components/librarianhomepage/librarianhomepage';
import { Issuebook } from './components/issuebook/issuebook';
import { Managebook } from './components/managebook/managebook';
import { Addbook } from './components/addbook/addbook';
import { Updatebook } from './components/updatebook/updatebook';
import { Deletebook } from './components/deletebook/deletebook';
import { Searchbook } from './components/searchbook/searchbook';
import { Viewallbook } from './components/viewallbook/viewallbook';
import { Reservebook } from './components/reservebook/reservebook';
import { Returnbook } from './components/returnbook/returnbook';
import { Addlibrarian } from './components/addlibrarian/addlibrarian';
import { Reports } from './components/reports/reports';
import { Updatepassword } from './components/updatepassword/updatepassword';
import { About } from './components/about/about';





const routes: Routes = [
  { path: '', component: Welcome },
  { path: 'login', component: Login },
  { path: 'register', component: Readerregister },

  { path: 'readerhomepage', component: Readerhomepage },
  { path: 'librarianhomepage', component: Librarianhomepage },

  { path: 'issuebook', component: Issuebook },
  { path: 'managebook', component: Managebook },

  { path: 'addbook', component: Addbook },
  { path: 'updatebook', component: Updatebook },
  { path: 'deletebook', component: Deletebook },
  { path: 'searchbook', component: Searchbook },

  { path: 'viewallbook', component: Viewallbook },

  // FIXED ROUTE
  { path: 'reservebook', component: Reservebook },
 { path: 'returnbook', component: Returnbook },
{path:'addlibrarian',component:Addlibrarian},
{path:'reports',component:Reports},
{path:'update-password',component:Updatepassword},
{path:'about',component:About}
  
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
