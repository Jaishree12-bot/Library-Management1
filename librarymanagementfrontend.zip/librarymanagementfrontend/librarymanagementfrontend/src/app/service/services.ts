import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Services {

  private readerUrl = 'http://localhost:8080/reader/api';
  private bookUrl = 'http://localhost:8080/book/api';
  private issueUrl = 'http://localhost:8080/issue/api';

  constructor(private http: HttpClient) {}

  // RETURN BOOK
  returnBook(issueId: number): Observable<any> {
    return this.http.put(
      `${this.issueUrl}/return/${issueId}`,
      {},
      { responseType: 'text' as 'json' }
    );
  }

  // RESERVATIONS
  reserveBook(data: any) {
    return this.http.post("http://localhost:8080/reserve/api", data);
  }

  getReservationsByReader(readerId: number): Observable<any[]> {
    return this.http.get<any[]>(`http://localhost:8080/reserve/api/findbyreaderid/${readerId}`);
  }

  cancelReservation(reserveId: number): Observable<any> {
    return this.http.delete(`http://localhost:8080/reserve/api/${reserveId}`);
  }

  // IMAGE UPLOAD
  uploadImage(formData: FormData) {
    return this.http.post("http://localhost:8080/book/api/upload", formData);
  }

  // REPORTS
  getReaderReports(): Observable<any[]> {
    return this.http.get<any[]>("http://localhost:8080/report/api/readers-report");
  }

  // BOOK CRUD
  getBookById(bookId: number): Observable<any> {
    return this.http.get(`${this.bookUrl}/${bookId}`);
  }

  updateBook(bookId: number, book: any): Observable<any> {
    return this.http.put(`${this.bookUrl}/${bookId}`, book);
  }

  addBook(book: any): Observable<any> {
    return this.http.post(this.bookUrl, book);
  }

  deleteBook(bookId: number): Observable<any> {
    return this.http.delete(`${this.bookUrl}/${bookId}`, { responseType: 'text' });
  }

  getAllBooks(): Observable<any[]> {
    return this.http.get<any[]>(this.bookUrl);
  }

  findByBookName(name: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.bookUrl}/findbybookname/${name}`);
  }

  findByCategoryAndAuthor(category: string, author: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${this.bookUrl}/findbycategoryandauthor/${category}/${author}`
    );
  }

  // READERS
  getAllReaders(): Observable<any[]> {
    return this.http.get<any[]>(`${this.readerUrl}/readers-only`);
  }

  registerReader(reader: any): Observable<any> {
    return this.http.post(this.readerUrl, reader);
  }

 loginReader(data: any) {
  return this.http.post(
    'http://localhost:8080/reader/api/login',
    data
  );
}




  // ISSUE API
  getIssuedBooks(readerId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.issueUrl}/reader/${readerId}`);
  }

  getLastIssuedBooks(): Observable<any[]> {
    return this.http.get<any[]>(`${this.issueUrl}/last`);
  }

  getIssuedToday(): Observable<any> {
    return this.http.get(`${this.issueUrl}/today`);
  }

  getOverdueBooks(): Observable<any> {
    return this.http.get(`${this.issueUrl}/overdue`);
  }

  issueBook(data: any): Observable<any> {
    return this.http.post(this.issueUrl, data);
  }

  // UPDATE PASSWORD
  updatePassword(id: number, body: any) {
    return this.http.put(
      `${this.readerUrl}/update-password/${id}`,
      body,
      { responseType: 'text' }
    );
  }

  // DASHBOARD API FOR READER
  getReaderDashboard(readerId: number): Observable<any> {
    return this.http.get(`${this.readerUrl}/dashboard/${readerId}`);
  }

  getBookSuggestions(query: string): Observable<any[]> {
  return this.http.get<any[]>(`${this.bookUrl}/search/${query}`);
}

}
