package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Reserve;

@Repository
public interface ReserveRepository extends JpaRepository<Reserve, Integer> {

    // ✔ Correct method naming convention
    List<Reserve> findByReaderId(int readerId);

    List<Reserve> findByBookId(int bookId);

	int countByReaderId(int readerId);
	
	boolean existsByReaderIdAndBookId(int readerId, int bookId);

}
