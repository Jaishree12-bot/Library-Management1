package com.example.demo.model;

public class AuthResponse {
    private boolean success;
    private String message;
    private Readers reader;

    public AuthResponse(boolean success, String message, Readers reader) {
        this.success = success;
        this.message = message;
        this.reader = reader;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public Readers getReader() {
        return reader;
    }
}
