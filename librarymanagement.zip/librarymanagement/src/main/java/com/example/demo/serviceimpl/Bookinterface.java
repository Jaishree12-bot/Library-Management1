package com.example.demo.serviceimpl;

import java.util.List;

import com.example.demo.model.Book;

public interface Bookinterface {

	public Book saveBook(Book book);

	public List<Book> getAllBooks();

	public Book getBookByBookId(int bookId);

	public Book updateBookByBookId(int bookId, Book book);

	public void deleteBookById(int bookId);

	public List<Book> getBookListAfterDeleteById(int bookId);

	// extra custom methods (because your controller uses them)
	public List<Book> findBookByName(String bookName);

	public List<Book> findBookByCategoryAndAuthor(String category, String author);
}
