package com.example.demo.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.LastIssuedDTO;
import com.example.demo.model.Issue;
import com.example.demo.repository.IssueRepository;
import com.example.demo.serviceimpl.Issueinterface;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/issue/api")
@CrossOrigin(origins = "http://localhost:4200")
public class IssueController {

    @Autowired
    private Issueinterface issueService;

    @Autowired
    private IssueRepository issueRepository;

    // ----------------- CREATE ISSUE -----------------
   
    // ----------------- OTHER ENDPOINTS -----------------

    @GetMapping
    public List<Issue> getAllIssues() {
        return issueService.getAllIssues();
    }

    @GetMapping("/id/{issueId}")
    public Issue getIssueByIssueId(@PathVariable int issueId) {
        return issueService.getIssueByIssueId(issueId);
    }

    @PutMapping("/id/{issueId}")
    public Issue updateIssueByIssueId(@PathVariable int issueId, @RequestBody Issue issue) {
        return issueService.updateIssueByIssueId(issueId, issue);
    }

    @DeleteMapping("/id/{issueId}")
    public String deleteIssueByIssueId(@PathVariable int issueId) {
        issueService.deleteIssueById(issueId);
        return "Issue deleted successfully " + issueId;
    }

    @DeleteMapping("/findAllIssues/{issueId}")
    public List<Issue> deleteIssueAndGetList(@PathVariable int issueId) {
        return issueService.getIssueListAfterDeleteById(issueId);
    }

    @GetMapping("/reader/{readerId}")
    public List<Issue> getIssuedBooksByReader(@PathVariable int readerId) {
        return issueService.getIssuedBooksForReader(readerId);
    }

    @GetMapping("/findbybook/{bookId}")
    public List<Issue> findIssuesByBookId(@PathVariable int bookId) {
        return issueService.findIssueByBookId(bookId);
    }

    @PutMapping("/return/{issueId}")
    public ResponseEntity<String> returnBook(@PathVariable int issueId) {
        Issue issue = issueRepository.findById(issueId).orElse(null);

        if (issue == null) {
            return ResponseEntity.status(404).body("Issue record not found");
        }

        issue.setStatus("RETURNED");
        issue.setActualReturnDate(LocalDate.now());

        issueRepository.save(issue);

        return ResponseEntity.ok("Book returned successfully");
    }

    @GetMapping("/last")
    public List<LastIssuedDTO> getLastIssuedBooks() {
        return issueService.getLastIssued();
    }

    @GetMapping("/today")
    public List<Issue> getTodayIssuedBooks() {
        return issueService.getTodayIssued();
    }

    @GetMapping("/overdue")
    public List<Issue> getOverdueBooks() {
        return issueService.getOverdueIssues();
    }
    @PostMapping
    public ResponseEntity<?> saveIssue(@Valid @RequestBody Issue issue) {

        // 1️⃣ CHECK — SAME BOOK ALREADY ISSUED TO SAME READER & NOT RETURNED
        Issue existing = issueRepository.findActiveIssuedBook(
                issue.getReaderId(),
                issue.getBookId()
        );

        if (existing != null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("This book is already issued to this reader!");
        }

        // 2️⃣ CHECK — How many copies already issued
        int issuedCount = issueRepository.countIssuedCopies(issue.getBookId());

        // 3️⃣ CHECK — Total copies present in Book table
        Integer totalCopies = issueRepository.findBookCopies(issue.getBookId());
        if (totalCopies == null) {
            totalCopies = 1; // default
        }

        // 4️⃣ IF ALL COPIES ARE ISSUED → STOP
        if (issuedCount >= totalCopies) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("All " + totalCopies + " copies of this book are already issued!");
        }

        // 5️⃣ Validation: Return date cannot be before issue date
        if (issue.getReturnDate().isBefore(issue.getIssueDate())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Return date cannot be before issue date!");
        }

        // 6️⃣ SAVE the record
        issue.setStatus("ISSUED");
        Issue savedIssue = issueService.saveIssue(issue);

        return ResponseEntity.status(HttpStatus.CREATED).body(savedIssue);
    }

}
