package com.example.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFound;
import com.example.demo.model.Book;
import com.example.demo.repository.BookRepository;

@Service
public class BookServiceImpl implements Bookinterface {

    @Autowired
    private BookRepository bookRepository;

    @Override
    public Book saveBook(Book book) {
        return bookRepository.save(book);
    }

    @Override
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    @Override
    public Book getBookByBookId(int bookId) {
        return bookRepository.findById(bookId)
                .orElseThrow(() -> new ResourceNotFound("Book", "bookId", bookId));
    }

    @Override
    public Book updateBookByBookId(int bookId, Book newBook) {
        Book existingBook = getBookByBookId(bookId);

        existingBook.setBookName(newBook.getBookName());
        existingBook.setAuthor(newBook.getAuthor());
        existingBook.setCategory(newBook.getCategory());
        existingBook.setPublisherName(newBook.getPublisherName());
        existingBook.setPublishYear(newBook.getPublishYear());

        return bookRepository.save(existingBook);
    }

    @Override
    public void deleteBookById(int bookId) {
        bookRepository.deleteById(bookId);
    }

    @Override
    public List<Book> getBookListAfterDeleteById(int bookId) {
        deleteBookById(bookId);
        return bookRepository.findAll();
    }

    @Override
    public List<Book> findBookByName(String bookName) {
        return bookRepository.findByBookName(bookName);
    }

    @Override
    public List<Book> findBookByCategoryAndAuthor(String category, String author) {
        return bookRepository.findByCategoryAndAuthor(category, author);
    }
}


