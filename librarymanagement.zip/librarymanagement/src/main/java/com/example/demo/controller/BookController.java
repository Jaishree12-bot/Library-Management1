package com.example.demo.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.Book;
import com.example.demo.repository.BookRepository;
import com.example.demo.serviceimpl.Bookinterface;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/book/api")
public class BookController {

    @Autowired
    private Bookinterface bookService;

    @Autowired
    private BookRepository bookRepo;

    // SAVE BOOK
    @PostMapping
    public ResponseEntity<Book> saveBook(@RequestBody Book book) {
        Book savedBook = bookService.saveBook(book);
        return new ResponseEntity<>(savedBook, HttpStatus.CREATED);
    }

    // GET ALL BOOKS
    @GetMapping
    public List<Book> getAllBooks() {
        return bookService.getAllBooks();
    }

    // GET BOOK BY ID
    @GetMapping("/{bookId}")
    public Book getBookById(@PathVariable int bookId) {
        return bookService.getBookByBookId(bookId);
    }

    // UPDATE BOOK
    @PutMapping("/{bookId}")
    public Book updateBook(@PathVariable int bookId, @RequestBody Book updated) {
        return bookService.updateBookByBookId(bookId, updated);
    }

    // DELETE BOOK
    @DeleteMapping("/{bookId}")
    public ResponseEntity<String> deleteBook(@PathVariable int bookId) {
        bookService.deleteBookById(bookId);
        return ResponseEntity.ok("Deleted Successfully");
    }

    // FIND BY NAME (exact)
    @GetMapping("/findbybookname/{bname}")
    public List<Book> findByBookName(@PathVariable String bname) {
        return bookService.findBookByName(bname);
    }

    // SEARCH with autocomplete
    @GetMapping("/search/{query}")
    public List<Book> searchBooks(@PathVariable String query) {
        return bookRepo.findByBookNameContainingIgnoreCase(query);
    }

    // FIND BY CATEGORY + AUTHOR
    @GetMapping("/findbycategoryandauthor/{category}/{author}")
    public List<Book> findByCategoryAndAuthor(@PathVariable String category,
                                              @PathVariable String author) {
        return bookService.findBookByCategoryAndAuthor(category, author);
    }

    // IMAGE UPLOAD
    @PostMapping("/upload")
    public ResponseEntity<Map<String, String>> uploadImage(@RequestParam("file") MultipartFile file) {

        try {
            String uploadDir = System.getProperty("user.dir") + "/uploads/";
            File directory = new File(uploadDir);

            if (!directory.exists()) {
                directory.mkdirs();
            }

            String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
            Path filePath = Paths.get(uploadDir + fileName);

            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            Map<String, String> response = new HashMap<>();
            response.put("imageUrl", "http://localhost:8080/uploads/" + fileName);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of("error", "Image upload failed"));
        }
    }
}
