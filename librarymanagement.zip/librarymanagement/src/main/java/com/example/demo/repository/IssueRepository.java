package com.example.demo.repository;

import com.example.demo.dto.LastIssuedDTO;
import com.example.demo.model.Issue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface IssueRepository extends JpaRepository<Issue, Integer> 
{

    // ---------------- BASIC FINDERS ----------------
    List<Issue> findByReaderId(Integer readerId);

    List<Issue> findByBookId(Integer bookId);

    List<Issue> findByBookIdAndStatus(Integer bookId, String status);


    // ---------------- DASHBOARD REPORTS ----------------

    // ✔ OLD RAW QUERY (kept for other modules)
    @Query(value = "SELECT * FROM issue_table ORDER BY issuedate DESC LIMIT 10", nativeQuery = true)
    List<Issue> findLastIssuedRaw();

    // ✔ NEW DASHBOARD DTO QUERY (bookName + readerName)
    @Query("""
        SELECT new com.example.demo.dto.LastIssuedDTO(
            b.bookName,
            r.readerName,
            i.issueDate,
            i.returnDate
        )
        FROM Issue i
        LEFT JOIN Book b ON i.bookId = b.bookId
        LEFT JOIN Readers r ON i.readerId = r.readerId
        ORDER BY i.issueDate DESC
        """)
    List<LastIssuedDTO> findLastIssued();


    @Query(value = "SELECT * FROM issue_table WHERE issuedate = :today", nativeQuery = true)
    List<Issue> findTodayIssued(LocalDate today);

    @Query(value = "SELECT * FROM issue_table WHERE returndate < :today AND status = 'ISSUED'", nativeQuery = true)
    List<Issue> findOverdue(LocalDate today);


    // ---------------- DUPLICATE ISSUE PREVENTION ----------------

    @Query(value =
            "SELECT * FROM issue_table " +
            "WHERE readerid = :readerId AND bookid = :bookId AND status = 'ISSUED' LIMIT 1",
            nativeQuery = true)
    Issue findActiveIssuedBook(Integer readerId, Integer bookId);


    // ---------------- BOOK COPIES VALIDATION ----------------

    @Query("SELECT COUNT(i) FROM Issue i WHERE i.bookId = :bookId AND i.status = 'ISSUED'")
    int countIssuedCopies(Integer bookId);

    @Query("SELECT b.copies FROM Book b WHERE b.bookId = :bookId")
    Integer findBookCopies(Integer bookId);


    // ---------------- REPORT HELPERS ----------------

    @Query(value =
            "SELECT readerid, COUNT(*) AS totalBooks " +
            "FROM issue_table " +
            "WHERE status = 'ISSUED' " +
            "GROUP BY readerid",
            nativeQuery = true)
    List<Object[]> getReaderActivity();

	int countByReaderIdAndStatus(int readerId, String status);

	
	
}
