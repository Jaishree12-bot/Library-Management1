package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name = "issue_table")
public class Issue {

    @Id
    @Column(name = "issueid")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int issueId;

    @NotNull
    @Positive
    @Column(name = "readerid")
    private Integer readerId;

    @NotNull
    @Positive
    @Column(name = "bookid")
    private Integer bookId;

    @NotNull
    @Column(name = "issuedate")
    private LocalDate issueDate;

    @NotNull
    @Column(name = "returndate")
    private LocalDate returnDate;

    // ⭐ STATUS FIELD (ISSUED or RETURNED)
    @Column(name = "status")
    private String status;

    // ⭐ ACTUAL RETURN DATE
    @Column(name = "actualreturndate")
    private LocalDate actualReturnDate;


    // ❌ REMOVED (BUG CAUSING VALIDATION)
    // @AssertTrue(message = "Issue date cannot be a past date", groups = OnCreate.class)
    // public boolean isIssueDateValid() {
    //     return !this.issueDate.isBefore(LocalDate.now());
    // }

    @AssertTrue(message = "Return date cannot be a past date")
    public boolean isReturnDateValid() {
        return returnDate == null || !returnDate.isBefore(LocalDate.now());
    }

    @AssertTrue(message = "Return date cannot be before issue date")
    public boolean isReturnAfterIssue() {
        return issueDate == null || returnDate == null || !returnDate.isBefore(issueDate);
    }


    // ---------------- Getters & Setters ----------------

    public int getIssueId() {
        return issueId;
    }
    public void setIssueId(int issueId) {
        this.issueId = issueId;
    }

    public Integer getReaderId() {
        return readerId;
    }
    public void setReaderId(Integer readerId) {
        this.readerId = readerId;
    }

    public Integer getBookId() {
        return bookId;
    }
    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }
    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }
    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getActualReturnDate() {
        return actualReturnDate;
    }
    public void setActualReturnDate(LocalDate actualReturnDate) {
        this.actualReturnDate = actualReturnDate;
    }
}
