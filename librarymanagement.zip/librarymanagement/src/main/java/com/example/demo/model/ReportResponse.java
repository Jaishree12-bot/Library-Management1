package com.example.demo.model;

import java.util.List;

public class ReportResponse {
    private int readerId;
    private String readerName;
    private int totalBooksTaken;
    private List<String> bookNames;

    public ReportResponse() {}

    public ReportResponse(int readerId, String readerName, int totalBooksTaken, List<String> bookNames) {
        this.readerId = readerId;
        this.readerName = readerName;
        this.totalBooksTaken = totalBooksTaken;
        this.bookNames = bookNames;
    }

    // getters + setters
    public int getReaderId() { return readerId; }
    public void setReaderId(int readerId) { this.readerId = readerId; }

    public String getReaderName() { return readerName; }
    public void setReaderName(String readerName) { this.readerName = readerName; }

    public int getTotalBooksTaken() { return totalBooksTaken; }
    public void setTotalBooksTaken(int totalBooksTaken) { this.totalBooksTaken = totalBooksTaken; }

    public List<String> getBookNames() { return bookNames; }
    public void setBookNames(List<String> bookNames) { this.bookNames = bookNames; }
}

